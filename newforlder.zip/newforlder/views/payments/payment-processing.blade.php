@extends('layouts.app')

@section('content')
    {{-- processing payment page --}}
    <h1>processing</h1>
@endsection
